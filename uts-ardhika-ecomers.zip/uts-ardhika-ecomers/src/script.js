let cart = [];

function addToCart(product, price) {
    // Cek apakah produk sudah ada di keranjang
    const existingProduct = cart.find(item => item.product === product);

    if (existingProduct) {
        // Jika produk sudah ada, tambahkan quantity
        existingProduct.quantity += 1;
    } else {
        // Jika produk belum ada, tambahkan produk baru dengan quantity 1
        cart.push({ product, price, quantity: 1 });
    }

    displayCart();
}

function displayCart() {
    const cartItems = document.getElementById('cart-items');
    const totalPriceElement = document.getElementById('total-price');
    
    cartItems.innerHTML = '';
    let total = 0;

    cart.forEach((item, index) => {
        cartItems.innerHTML += `
            <li>
                ${item.product} - $${item.price} x ${item.quantity} 
                <button onclick="changeQuantity(${index}, 'increase')">+</button>
                <button onclick="changeQuantity(${index}, 'decrease')">-</button>
                <button onclick="removeFromCart(${index})">Hapus</button>
            </li>
        `;
        total += item.price * item.quantity;
    });

    totalPriceElement.innerText = total.toFixed(2);
}

function changeQuantity(index, action) {
    if (action === 'increase') {
        cart[index].quantity += 1;
    } else if (action === 'decrease' && cart[index].quantity > 1) {
        cart[index].quantity -= 1;
    }
    displayCart();
}

function removeFromCart(index) {
    cart.splice(index, 1);
    displayCart();
}

function checkout() {
    if (cart.length === 0) {
        alert('Keranjang kosong!');
    } else {
        let total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
        alert(`Checkout berhasil! Total Pembelian: $${total.toFixed(2)}. Terima kasih telah berbelanja.`);
        cart = [];
        displayCart();
    }
}
